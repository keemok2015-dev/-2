import { createServerFn } from '@tanstack/react-start'
import { loadMatchFeed, loadStandings } from './matches.server'
import { leagueDefinitions } from '../lib/matches'

export const getMatchFeed = createServerFn({ method: 'GET' })
  .inputValidator((input: { timeZone: string }) => {
    if (!input || typeof input.timeZone !== 'string' || input.timeZone.length > 80) {
      throw new Error('المنطقة الزمنية غير صالحة')
    }
    try {
      new Intl.DateTimeFormat('ar', { timeZone: input.timeZone }).format()
    } catch {
      throw new Error('المنطقة الزمنية غير صالحة')
    }
    return { timeZone: input.timeZone }
  })
  .handler(({ data }) => loadMatchFeed(data.timeZone))

export const getStandings = createServerFn({ method: 'GET' })
  .inputValidator((input: { leagueId: string }) => {
    if (!input || typeof input.leagueId !== 'string' || !leagueDefinitions.some(l => l.id === input.leagueId)) {
      throw new Error('الدوري غير صالح')
    }
    return { leagueId: input.leagueId }
  })
  .handler(({ data }) => loadStandings(data.leagueId))
